rock = {
	Physics={
	},
	Position={
	},
	Graphics={
	},
}