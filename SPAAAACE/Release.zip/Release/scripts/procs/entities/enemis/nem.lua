nem = {
	Physics={
	},
	Position={
	},
	Graphics={
	},
}