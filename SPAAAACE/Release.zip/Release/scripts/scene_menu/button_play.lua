button_play = {
	Position = {
		x = 50,
		y = 650,
	},
	Graphics = {
		filename = "default__ressources/button_play.png 33selected__ressources/button_play_selected.png",
		anim_speed = 12,
		cam = "false"
	},
	Action = {
		trigger = "Scene button_play 34059 1",
		answer = "Action Button 34056 1"
	}
}