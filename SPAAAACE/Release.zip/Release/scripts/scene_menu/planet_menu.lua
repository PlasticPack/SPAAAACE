planet_menu	= {
	Position = {
		x = 1200,
		y = 0,
	},
	Graphics = {
		filename = "default__ressources/planet_menu_.png",
		anim_speed = 12,
		width = 1200,
		height = 1200
	},
	Physics = {
		vel_x = 0,
		vel_y = 150,
	}
}