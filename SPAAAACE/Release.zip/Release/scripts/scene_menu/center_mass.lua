center_mass	= {
	Position = {
		x = 0,
		y = 0,
		
	},
	Physics = {
		mass = 300,
		hitbox = 1
	}
}