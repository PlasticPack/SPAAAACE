button_quit = {
	Position = {
		x = 50,
		y = 750,
	},
	Graphics = {
		filename = "default__ressources/button_quit.png 33selected__ressources/button_quit_selected.png",
		anim_speed = 12,
		cam = "false"
	},
	Action = {
		trigger = "Scene button_quit 34059 1",
		answer = "Action Button 34058 1"
	}
}