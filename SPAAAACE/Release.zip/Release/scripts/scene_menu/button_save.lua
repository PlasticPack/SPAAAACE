button_save = {
	Position = {
		x = 425,
		y = 600,
	},
	Graphics = {
		filename = "default__ressources/button_save.png selected__ressources/button_save_selected.png full__ressources/button_save_full.png",
		cam = "false"
	},
	Action = {
		trigger = "Scene button_save 34059 1",
		answer = "Action Button 34056 1"
	}
}