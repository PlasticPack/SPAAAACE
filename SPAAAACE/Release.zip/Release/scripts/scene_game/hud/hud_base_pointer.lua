hud_base_pointer = {
	Position = {
		x = 25,
		y = 25,
		z = 1.03,
	},
	Graphics = {
		filename = "ressources/base_pointer.png",
		cam = "false"
	}
}