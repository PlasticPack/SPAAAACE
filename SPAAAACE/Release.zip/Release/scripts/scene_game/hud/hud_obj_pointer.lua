hud_obj_pointer = {
	Position = {
		x = 15,
		y = 15,
		z = 1.04,
	},
	Graphics = {
		filename = "ressources/obj_pointer.png",
		cam = "false"
	}
}