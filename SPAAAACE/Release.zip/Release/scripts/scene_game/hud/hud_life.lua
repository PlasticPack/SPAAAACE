hud_life = {
	Position = {
		x = 27,
		y = 107,
		z = 1.02,
	},
	Graphics = {
		filename = "ressources/life.png",
		cam = "false",
		width = 182,
		height = 32
	}
}