hud_fuel = {
	Position = {
		x = 28,
		y = 28,
		z = 1.02,
	},
	Graphics = {
		filename = "ressources/fuel.png",
		cam = "false",
		width = 300,
		height = 50
	}
}