hud_fuel_container = {
	Position = {
		x = 20,
		y = 20,
		z = 1.01,
	},
	Graphics = {
		filename = "ressources/fuel1.png",
		cam = "false",
		width = 316,
		height = 66
	}
}