hud_life_container = {
	Position = {
		x = 20,
		y = 100,
		z = 1.01,
	},
	Graphics = {
		filename = "ressources/life_container.png",
		cam = "false"
	}
}