yog_sogoth = {
	Position = {
		x = 84000,
		y = -18000,
		z = 1
	},
	Physics = {
		mass = 6000,
		hitbox = 1800,
		elasticity = 0.8,
		vel_a = 36,
		vel_x = 160,
		vel_y = -160
	},
	Graphics = {
		filename = "ressources/yog_sogoth.png",
		width = 5000,
		height = 5000
	}
}