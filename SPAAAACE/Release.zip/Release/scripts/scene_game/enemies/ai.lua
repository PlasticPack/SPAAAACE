ai = 
{
	Position = 
	{
		
		x = 200,
		
		y = 200,
	
	},
	
	Physics = 
	{
		
		mass = 2,
		
		hitbox = 50,
		
		elasticity = 0.99
	},
	
	Graphics = 
	{
		
		filename = "ressources/ennemi.png",
		
		c = 4,
		
		r = 1,
		
		anim_speed = 5,
		
		width = 50,
		
		height = 50
	
	},
	GameLogic =  {
		pwr = 2000,
		fuel = 20000,
		life = 30
	},
	AI = {
	}
}