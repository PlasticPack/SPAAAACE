trigger1 = {
	Position = {
		x = 200,
		y = 0
	},
	Physics = {
		hitbox = 150,
		activated = "false"
	},
	Action = {
		trigger = "player trigger1 34048 1",
		answer = "Action Exploser\\le\\machin 34063 1",
		timer = -1
	}
}