base = {
	Position = {
		x = 8000,
		y = 0000,
		z = 0.88
	},
	Physics = {
		mass = 9000,
		hitbox = 1500,
		elasticity = 0.6,
		vel_a = 4
	},
	Graphics = {
		filename = "ressources/base.png",
		width = 3000,
		height = 3000
	}
}