star = {
	Position = {
		x = 0,
		y = 0,
		fixed = true,
	},
	Physics = {
		mass = 700,
		hitbox = 500,
		elasticity = 0.89,
		vel_x = 150,
		vel_y = -160
	},
	Graphics = {
		filename = "ressources/planet_1.png",
		width = 1000,
		height = 1000
	}
}