player = {
	Position = {
		x = 5,
		y = 0,
		a = 0
	},
	Physics = {
		mass = 4,
		hitbox = 16,
		elasticity = 0.8
	},
	Graphics = {
		filename = "default__ressources/single_ship.png 55explosion__ressources/explosion.png",
		anim_speed = 12
	},
	GameLogic =  {
		pwr = 4000,
		fuel = 40000,
		life = 15
	}
}