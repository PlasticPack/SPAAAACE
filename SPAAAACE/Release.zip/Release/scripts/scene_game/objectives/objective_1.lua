objective_1 = {
	Position = {
		x = 8000,
		y = 0
	},
	Physics = {
		hitbox = 1500,
		activated = "false"
	},
	Action = {
		trigger = "player base 34048 1",
		answer = "Action objective_1 34063 1",
		timer = 1
	},
	Objective = {
		name = "Trouver la base",
		target = "base"
	}
}