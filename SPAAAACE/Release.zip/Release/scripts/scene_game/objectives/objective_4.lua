objective_4 = {
	Position = {
		x = 4000,
		y = -4000
	},
	Physics = {
		hitbox = 3200,
		activated = "false"
	},
	Action = {
		trigger = "player objective_4 34048 1",
		answer = "Action objective_4 34063 1",
		timer = 1
	},
	Objective = {
		name = "Trouver Yog-Sogoth, terreur cosmique",
		target = "yog_sogoth"
	}
}