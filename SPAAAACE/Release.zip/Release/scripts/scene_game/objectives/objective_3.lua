objective_3 = {
	Position = {
		x = 4000,
		y = -4000
	},
	Physics = {
		hitbox = 31200,
		activated = "false"
	},
	Action = {
		trigger = "player yog_sogoth 34048 1",
		answer = "Action objective_3 34063 1",
		timer = 1
	},
	Objective = {
		name = "Trouver Yog-Sogoth, terreur cosmique",
		target = "yog_sogoth"
	}
}