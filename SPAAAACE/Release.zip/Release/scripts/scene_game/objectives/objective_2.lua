objective_2 = {
	Position = {
		x = 0000,
		y = 2000,
	},
	Physics = {
		hitbox = 1300,
		activated = "false"
	},
	Action = {
		trigger = "player objective_2 34048 1",
		answer = "Action objective_2 34063 1",
		timer = 1
	},
	Objective = {
		name = "Trouver la planete Omega",
		target = "planetOmega"
	}
}