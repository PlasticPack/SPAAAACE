nem1 = {
	Position = {
	},
	Physics = {
		mass = 10
	}
}